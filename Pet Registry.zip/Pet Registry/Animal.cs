﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pet_Registry
{
    public abstract class Animal
    {
        public Guid Id { get; } = Guid.NewGuid();
        public string Name { get; }
        public int Age { get; }

        public Animal(string name, int age)
        {
            Id = Guid.NewGuid();
            Name = name;
            Age = age;
        }

        public abstract decimal GetFee();
    }
}