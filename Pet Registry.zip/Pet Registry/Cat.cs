﻿using Pet_Registry;
using System.Windows.Controls;

public class Cat : Animal
{
    public Cat(string name, int age) : base(name, age) { }

    public override decimal GetFee()
    {
        return 40 + (5 * Age);
    }
}
