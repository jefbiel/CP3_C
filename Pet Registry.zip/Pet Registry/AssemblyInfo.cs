using System.Windows;

[assembly: ThemeInfo(
    ResourceDictionaryLocation.None,            
                                                
    ResourceDictionaryLocation.SourceAssembly   
)]
