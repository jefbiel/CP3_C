﻿using Pet_Registry;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace PetRegistry
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<AnimalViewModel> pets = new();

        public MainWindow()
        {
            InitializeComponent();
            PetsDataGrid.ItemsSource = pets; 
        }

        private void AddPet_Click(object sender, RoutedEventArgs e)
        {
            string name = NameTextBox.Text;
            if (!int.TryParse(AgeTextBox.Text, out int age) || string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Preencha corretamente o nome e a idade.");
                return;
            }

            string? type = ((ComboBoxItem?)TypeComboBox.SelectedItem)?.Content?.ToString();
            if (string.IsNullOrWhiteSpace(type))
            {
                MessageBox.Show("Selecione um tipo válido.");
                return;
            }

            Animal? animal = type switch
            {
                "Cachorro" => new Dog(name, age),
                "Gato" => new Cat(name, age),
                _ => null
            };

            if (animal != null)
            {
                pets.Add(new AnimalViewModel(animal));
                NameTextBox.Clear();
                AgeTextBox.Clear();
                TypeComboBox.SelectedIndex = -1;
            }
        }

        private void RemovePet_Click(object sender, RoutedEventArgs e)
        {
            if (PetsDataGrid.SelectedItem is AnimalViewModel selected)
            {
                pets.Remove(selected);
            }
        }

        private void CalculateTotal_Click(object sender, RoutedEventArgs e)
        {
            decimal total = pets.Sum(p => p.Fee);
            TotalTextBlock.Text = $"Total: R${total}";
        }

        public void AddPet()
        {
            NameTextBox.Text = "Rex"; 
        }

        private void NameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Name_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void AgeTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
        {

        }
    }

    public class AnimalViewModel
    {
        public Guid Id { get; }
        public string Name { get; }
        public int Age { get; }
        public decimal Fee { get; }

        public AnimalViewModel(Animal animal)
        {
            Id = animal.Id;
            Name = animal.Name;
            Age = animal.Age;
            Fee = animal.GetFee();
        }
    }
}